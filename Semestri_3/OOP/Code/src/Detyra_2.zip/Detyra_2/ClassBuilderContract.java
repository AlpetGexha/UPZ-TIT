package Detyra_2;

import java.util.List;

public interface ClassBuilderContract {
    List<AttributeObject> getAttributes();
    String getClassName();
}