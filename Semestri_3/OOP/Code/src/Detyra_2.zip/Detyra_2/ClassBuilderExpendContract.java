package Detyra_2;

public interface ClassBuilderExpendContract {
    void extend(ClassBuilder.Builder builder);
}
